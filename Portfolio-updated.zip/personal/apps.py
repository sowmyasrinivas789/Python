from django.apps import AppConfig


class PersonalConfig(AppConfig):
    name = 'personal'
