var slideIndex = 1;

$(document).ready(function(){
    	$('.menu').click(function(){
		document.getElementById("option-list").style.width = "30%";
		$('.menu').hide();
	})
	$('.close-btn').click(function(){
		$('.menu').show();
		document.getElementById("option-list").style.width = "0";
	})
	$('.arrow').click(function(){
		var i;
		var x = document.getElementsByClassName("mySlides");
		if (this.id == 'left') {n = -1;}
		else {n = 1;}
		slideIndex += n
		if (slideIndex > x.length) {slideIndex = 1}
		if (slideIndex < 1) {slideIndex = x.length}
		for (i = 0; i < x.length; i++) {
			x[i].style.display = "none";
		}
		x[slideIndex-1].style.display = "block";
	})
	$('.option').click(function(e){
		tag_id = '/' + this.id + '/';
		$.ajax({
			type : 'GET',
			url : tag_id,
			success: function(data){
                $('body').html(data);
            }
		});
	})
	$('.resume-container li').click(function(){
		classname = this.id
		$('.resume-container .text' ).hide();
		$('.resume-container .' + classname).show();
	});
});

var modal = document.getElementById('myModal');
var modalImg = document.getElementById("img01");
var span = document.getElementsByClassName("close")[0];

$('.mySlides').click(function(){
	var img = this.id
	modal.style.display = "block";
    modalImg.src = this.src;
})

span.onclick = function() {
    modal.style.display = "none";
}
