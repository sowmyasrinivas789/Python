const button = document.querySelector('.dots')
const slide = document.querySelector('.slide')

button.addEventListener('click', function() {
	slide.classList.toggle('is-hidden')
})

$(document).ready(function(){
	$('.middle').click(function(){ 
		$('.labels').toggle('slow');
		$('.main_container .slide-label').slideToggle('slow');
	});
	$('.slide-label li, .labels li').click(function(){
		$('.content').hide();
		var myClass = this.className
		$('.' + myClass).show();
	});
	$('.resume-label li').click(function(){
		$('.text').hide();
		$('.' + this.className).show();
		this.removeClass('active');
	});
	// for image shift
	var img;
	$('.righ').click(function(){
		img = $('.big').attr('value');
		++img; 
		if( img == 7){
			img = 1;
		};
		$('.image').attr('src','img/paints/p'+img+'.jpg').attr('value',img);
	});
	$('.lef').click(function(){
		img = $('.big').attr('value');
		--img;
		if( img == 0){
			img = 6;
		}
		$('.image').attr('src','img/paints/p'+img+'.jpg').attr('value',img);
	});
});