from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    text_info = "Hello World"
    return render(request, "personal/index.html", {'text':text_info})

def paint(request):
    names = ['p6.jpg', 'p1.jpg', 'p5.jpg']
    text_info = ['img/paints/' + each for each in names]
    return render(request, "personal/index.html", {'images':text_info})

def contact(request):
    text_info = "contact"
    return render(request, "personal/index.html", {'text2':text_info})

def resume(request):
    text_info = "resume"
    return render(request, "personal/index.html", {'text3':text_info})
