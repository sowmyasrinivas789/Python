export const vegetables = [
  "tomato",
  "onion",
  "potato",
  "broccoli",
  "cabbage",
  "carrot"
];
export const fruits = [
  "watermelon",
  "grapes",
  "orange",
  "apple",
  "bananas",
  "strawberry",
  "pineapple"
];
export const other = ["milk", "pasta", "croissant", "mustard", "eggs", "jam"];
