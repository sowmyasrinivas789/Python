![Alt text](screen1.png?raw=true "Intro")

# Teddy games

https://pylnata.github.io/teddy/

React App with cartoon animations and games for kids. 
Developed just for fun and to learn React-spring library for animations.

Used:
* create-react-app;
* styled-components;
* react-spring; ( all 5 hooks);
* functional components and react-hooks only.

During development I also have written an article about import and preloading of bunch of images:

https://medium.com/@pylnata/import-and-preloading-of-bunch-of-images-in-react-app-c82068d26247

Additional screenshots:

Shop game
![Alt text](screen2.png?raw=true "Shop game")

Puzzle game
![Alt text](screen3.png?raw=true "Puzzle game")

