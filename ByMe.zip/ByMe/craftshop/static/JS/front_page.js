var lists = ["Page1", "Page2", "Page3", "Page1", "Page2", "Page3"];
for (var i in lists){
	$('#menu-list ul').append("<li class='dropdown'><a class='dropdown-toggle' id='" + lists[i] + "' data-toggle='dropdown' href='#'>"+ lists[i] + " <span class='caret'></span></a></li>")
	$('#menu-list #' + lists[i] + '').append("<ul class='dropdown-menu'><li><a href='#'>Page 1-1</a></li><li><a href='#'>Page 1-2</a></li><li><a href='#'>Page 1-3</a></li></ul></li>");
}

var myIndex = 0;
carousel();
function carousel() {
	var i;
	var x = document.getElementsByClassName("imageSlides");
	var dots = document.getElementsByClassName("dot");
	for (i = 0; i < x.length; i++) {
	   x[i].style.display = "none";
	}
	myIndex++;
	if (myIndex > x.length) {myIndex = 1}
	for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
	x[myIndex-1].style.display = "block";
	dots[myIndex-1].className += " active";
	setTimeout(carousel, 2000); // Change image every 2 seconds
}
