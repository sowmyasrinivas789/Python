from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cover_page', views.cover_page, name='cover_page'),
    path('register_page', views.register_page, name='register_page'),
    path('login_page', views.login_page, name='login_page'),
    path('first_page', views.first_page, name='first_page'),
]