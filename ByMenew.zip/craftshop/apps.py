from django.apps import AppConfig


class CraftshopConfig(AppConfig):
    name = 'craftshop'
