from django.shortcuts import render
from django.http import HttpResponse
import os

def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def cover_page(request):
    return render(request, 'cover_page.html', {'result': "template created"})

def register_page(request):
    return render(request, 'register_page.html', {'result': "template created"})

def login_page(request):
    return render(request, 'login_page.html', {'result': "template created"})

def first_page(request):
    path = "E:\D-Project\ByMe\craftshop\static\img\display"
    img_list = os.listdir(path)
    return render(request, 'first_page.html', {'images': img_list})